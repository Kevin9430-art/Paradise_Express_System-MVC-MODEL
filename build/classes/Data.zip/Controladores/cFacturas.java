/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

/**
 *
 * @author mjair
 */
import Modelos.Factura;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.table.DefaultTableModel;

public class cFacturas {

    public static final String SEPARADOR = ";";
    public static final String QUOTE = "\"";
    public String path = Global.getPath() + "\\Data\\dataFacturas.csv";

    private ArrayList<Factura> listaFacturas = new ArrayList<>();

    // Acceso a clientes para validación
    private cCliente controladorClientes;

    public cFacturas(cCliente controladorClientes) {
        this.controladorClientes = controladorClientes;
    }

    public int Cantidad() {
        return listaFacturas.size();
    }

    public void Limpiar() {
        listaFacturas.clear();
    }

    public Factura getFactura(int posicion) {
        if (posicion >= 0 && posicion < listaFacturas.size()) {
            return listaFacturas.get(posicion);
        }
        return null;
    }

    public int localizar(String numFactura) {
        for (int i = 0; i < Cantidad(); i++) {
            if (numFactura.equals(listaFacturas.get(i).getNumFactura())) {
                return i;
            }
        }
        return -1;
    }

    public void nuevo(Factura f) throws IOException {
        int pos = localizar(f.getNumFactura());
        if (pos == -1) {
            if (controladorClientes.localizar(f.getCedulaCliente()) != -1) {
                listaFacturas.add(f);
            } else {
                throw new RuntimeException("** El cliente con cédula " + f.getCedulaCliente() + " no está registrado **");
            }
        } else {
            throw new RuntimeException("** La factura con número " + f.getNumFactura() + " ya existe **");
        }
    }

    public void modificar(Factura f, String numFactura) throws IOException {
        int pos = localizar(numFactura);
        if (pos > -1) {
            if (controladorClientes.localizar(f.getCedulaCliente()) != -1) {
                listaFacturas.set(pos, f);
            } else {
                throw new RuntimeException("** El cliente con cédula " + f.getCedulaCliente() + " no está registrado **");
            }
        } else {
            throw new RuntimeException("** No existe factura con número: " + numFactura + " **");
        }
    }

    public void eliminar(String numFactura) throws IOException {
        int pos = localizar(numFactura);
        if (pos > -1) {
            listaFacturas.remove(pos);
        } else {
            throw new RuntimeException("** No existe factura con número: " + numFactura + " **");
        }
    }

    public DefaultTableModel getTabla() {
        String[] columnName = {"N° Factura", "RUC", "Cédula Cliente", "Fecha Emisión", "Total", "Forma de Pago"};
        DefaultTableModel tabla = new DefaultTableModel(columnName, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Factura f : listaFacturas) {
            Object[] row = {
                f.getNumFactura(), f.getRUC(), f.getCedulaCliente(),
                f.getFechaEmision(), f.getTotalFactura(), f.getFormaPago()
            };
            tabla.addRow(row);
        }

        return tabla;
    }

    public void leer() throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            System.out.println("Cargando facturas...");
            String line = br.readLine(); // Encabezado
            Limpiar();
            line = br.readLine();
            while (line != null) {
                String[] row = line.split(SEPARADOR);
                removeTrailingQuotes(row);

                Factura f = new Factura(
                        row[0], // numFactura
                        row[1], // RUC
                        row[2], // cedulaCliente
                        row[3], // fecha
                        Double.parseDouble(row[4]), // total
                        row[5] // forma de pago
                );
                nuevo(f);
                line = br.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException("** Error al leer archivo de facturas **");
        } finally {
            if (br != null) br.close();
        }
    }

    private static String[] removeTrailingQuotes(String[] fields) {
        String[] result = new String[fields.length];
        for (int i = 0; i < fields.length; i++) {
            result[i] = fields[i].replaceAll("^" + QUOTE, "").replaceAll(QUOTE + "$", "");
        }
        return result;
    }

    public void guardar() throws IOException {
        FileWriter file;
        try {
            file = new FileWriter(path);
            final String NEXT_LINE = "\n";
            file.append("NumFactura").append(SEPARADOR);
            file.append("RUC").append(SEPARADOR);
            file.append("CedulaCliente").append(SEPARADOR);
            file.append("FechaEmision").append(SEPARADOR);
            file.append("TotalFactura").append(SEPARADOR);
            file.append("FormaPago").append(NEXT_LINE);

            for (Factura f : listaFacturas) {
                file.append(f.getNumFactura()).append(SEPARADOR);
                file.append(f.getRUC()).append(SEPARADOR);
                file.append(f.getCedulaCliente()).append(SEPARADOR);
                file.append(f.getFechaEmision()).append(SEPARADOR);
                file.append(String.valueOf(f.getTotalFactura())).append(SEPARADOR);
                file.append(f.getFormaPago()).append(NEXT_LINE);
            }

            file.flush();
            file.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException("** Error al guardar archivo de facturas **");
        }
    }
}
