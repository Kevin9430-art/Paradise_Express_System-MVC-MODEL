/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

/**
 *
 * @author mjair
 */
import Modelos.Cliente;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.table.DefaultTableModel;

public class cCliente {
    
    private static final String SEPARADOR = ";";
    private static final String QUOTE = "\"";
    public String path = Global.getPath() + "\\Data\\dataClientes.csv";
    
    private ArrayList<Cliente> listaClientes = new ArrayList<>();

    public int Cantidad(){
    return listaClientes.size();
    }
    
    public void Limpiar(){
    listaClientes.clear();
    }
    
    public Cliente geCliente(int posicion){
    Cliente c = null;
    if(posicion>=0 && posicion < listaClientes.size()){
        c = listaClientes.get(posicion);
    }
    return c;
    }
    
    public int localizar(String cedula){
    int pos= -1;
    for(int i=0;i<Cantidad();i++){
        Cliente c = listaClientes.get(i);
        if(cedula.equals(c.getCedula())){
            pos=i;
        }
    }
    return pos;
    }
    
    public void nuevo(Cliente c) throws IOException {
        int pos = localizar(c.getCedula());
        if (pos == -1) {
            listaClientes.add(c);
        } else {
            throw new RuntimeException("** Cliente ya registrado con cédula: " + c.getCedula() + " **");
        }
    }
    
    public void modificar(Cliente c, String cedula) throws IOException {
        int pos = localizar(cedula);
        if (pos > -1) {
            listaClientes.set(pos, c);
        } else {
            throw new RuntimeException("** No existe cliente con cédula: " + cedula + " **");
        }
    }
    
    public void eliminar(String cedula) throws IOException {
        int pos = localizar(cedula);
        if (pos > -1) {
            listaClientes.remove(pos);
        } else {
            throw new RuntimeException("** No existe cliente con cédula: " + cedula + " **");
        }
    }
    
    
    
    public DefaultTableModel getTabla() {
        String[] columnName = {"Cédula", "Nombre", "Apellido", "Celular", "Dirección", "Ciudad", "Email"};
        DefaultTableModel tabla = new DefaultTableModel(columnName, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (int i = 0; i < Cantidad(); i++) {
            Cliente c = listaClientes.get(i);
            Object[] row = {
                c.getCedula(), c.getNombre(), c.getApellido(),
                c.getCelular(), c.getDireccion(), c.getCiudad(), c.getEmail()
            };
            tabla.addRow(row);
        }

        return tabla;
    }
    
    
    public void leer() throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            System.out.println("Datos del archivo:");
            String line = br.readLine(); // saltar encabezado
            Limpiar();
            line = br.readLine();
            while (line != null) {
                String[] row = line.split(SEPARADOR);
                removeTrailingQuotes(row);
                Cliente c = new Cliente(
                    row[0], // nombre
                    row[1], // apellido
                    row[2], // cedula
                    row[3], // celular
                    row[4], // direccion
                    row[5], // ciudad
                    row[6]  // email
                );
                nuevo(c);
                System.out.println(Arrays.toString(row));
                line = br.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException("** Error al leer archivo de clientes **");
        } finally {
            if (br != null) br.close();
        }
    }
    
    
    private static String[] removeTrailingQuotes(String[] fields) {
        String result[] = new String[fields.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = fields[i].replaceAll("^" + QUOTE, "").replaceAll(QUOTE + "$", "");
        }
        return result;
    }
    
    
    public void guardar() throws IOException {
        FileWriter file;
        try {
            file = new FileWriter(path);
            final String NEXT_LINE = "\n";
            file.append("Nombre").append(SEPARADOR);
            file.append("Apellido").append(SEPARADOR);
            file.append("Cedula").append(SEPARADOR);
            file.append("Celular").append(SEPARADOR);
            file.append("Direccion").append(SEPARADOR);
            file.append("Ciudad").append(SEPARADOR);
            file.append("Email").append(NEXT_LINE);

            for (int i = 0; i < Cantidad(); i++) {
                Cliente c = listaClientes.get(i);
                file.append(c.getNombre()).append(SEPARADOR);
                file.append(c.getApellido()).append(SEPARADOR);
                file.append(c.getCedula()).append(SEPARADOR);
                file.append(c.getCelular()).append(SEPARADOR);
                file.append(c.getDireccion()).append(SEPARADOR);
                file.append(c.getCiudad()).append(SEPARADOR);
                file.append(c.getEmail()).append(NEXT_LINE);
            }

            file.flush();
            file.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException("** Error al guardar datos de clientes **");
        }
    }
    
    
    
}
