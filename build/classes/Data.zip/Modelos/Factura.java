/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author mjair
 */
public class Factura {
    
    private String numFactura;
    private String RUC;
    private String cedulaCliente;
    private String fechaEmision;
    private double totalFactura;
    private String formaPago; // "Efectivo" o "Transferencia"

    public Factura() {
    }

    public Factura(String numFactura, String RUC, String cedulaCliente, String fechaEmision, double totalFactura, String formaPago) {
        this.numFactura = numFactura;
        this.RUC = RUC;
        this.cedulaCliente = cedulaCliente;
        this.fechaEmision = fechaEmision;
        this.totalFactura = totalFactura;
        this.formaPago = formaPago;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(String numFactura) {
        this.numFactura = numFactura;
    }

    public String getRUC() {
        return RUC;
    }

    public void setRUC(String RUC) {
        this.RUC = RUC;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public double getTotalFactura() {
        return totalFactura;
    }

    public void setTotalFactura(double totalFactura) {
        this.totalFactura = totalFactura;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }
    
    
    
}
