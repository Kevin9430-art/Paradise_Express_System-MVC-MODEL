/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author mjair
 */
public class Vendedor {
    private String cedulav;
    private String nombrev;
    private String apellidov;
    private String celularv;
    private String ciudadv;

    public Vendedor() {
    }

    public Vendedor(String cedulav, String nombrev, String apellidov, String celularv, String ciudadv) {
        this.cedulav = cedulav;
        this.nombrev = nombrev;
        this.apellidov = apellidov;
        this.celularv = celularv;
        this.ciudadv = ciudadv;
    }

    public String getCedulav() {
        return cedulav;
    }

    public void setCedulav(String cedulav) {
        this.cedulav = cedulav;
    }

    public String getNombrev() {
        return nombrev;
    }

    public void setNombrev(String nombrev) {
        this.nombrev = nombrev;
    }

    public String getApellidov() {
        return apellidov;
    }

    public void setApellidov(String apellidov) {
        this.apellidov = apellidov;
    }

    public String getCelularv() {
        return celularv;
    }

    public void setCelularv(String celularv) {
        this.celularv = celularv;
    }

    public String getCiudadv() {
        return ciudadv;
    }

    public void setCiudadv(String ciudadv) {
        this.ciudadv = ciudadv;
    }
    
    
    
    
    
    
}
